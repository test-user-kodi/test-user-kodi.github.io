# coding: utf-8
import os
import sys

from collections import defaultdict

from urllib import quote_plus
from urlparse import parse_qsl
import urllib2
import time
import json
import socket

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import downloader
import extract

from kodi_version import KODI_VERSION

socket.setdefaulttimeout(30)
USER_AGENT = 'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB; rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3'
dialog = xbmcgui.Dialog()

PATH = 'multimediamaster'
_SERVER_ = 'http://techmani.webd.pl/techmani.webd.pl/multimediamaster/'

addon = xbmcaddon.Addon()
ADDON_VERSION = addon.getAddonInfo('version')


def show_categories():
    add_directory(name='Multimedia Master',
                  url='free',
                  mode='interactive',
                  iconimage=_SERVER_ + 'images/iconfree.png',
                  fanart=_SERVER_ + 'images/fanartfree.jpg',
                  description='Multimedia Master od TechManiacHD, znajdziesz mnie na YouTube')
    set_view('movies', 'MAIN')

    add_directory(name='[COLOR=blue]Multimedia[/COLOR] [COLOR=darkorange]Master[/COLOR] [COLOR=darkorange]Edycja[/COLOR] [COLOR=blue]Specjalna[/COLOR]',
                  url='paid',
                  mode='interactive',
                  iconimage=_SERVER_ + 'images/VIPicon.png',
                  fanart=_SERVER_ + 'images/VIPfanart.jpg',
                  description='Multimedia Master od TechManiacHD, znajdziesz mnie na YouTube')
    set_view('movies', 'MAIN')


def get_type(url):
    print 'get_type: {0!r}'.format(url)
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    content_type = response.info().getheader('Content-Type')
    response.close()
    return content_type


def get_content(url):
    print 'get_content: {0!r}'.format(url)
    req = urllib2.Request(url)
    req.add_header('User-Agent', USER_AGENT)
    response = urllib2.urlopen(req)
    data = response.read()
    response.close()
    return data


def download_build(build_type, password = ''):
    path = xbmc.translatePath(os.path.join('special://home/addons', 'packages'))
    zip_path = os.path.join(path, build_type + '.zip')

    try:
        os.remove(zip_path)
    except OSError:
        pass

    progress = xbmcgui.DialogProgress()
    progress.create('[I][COLOR=blue]Multimedia[/COLOR] [COLOR=orange]Master[/COLOR][/I]',
              '[B][COLOR yellow]Krok 1 -[/COLOR][/B] [COLOR violet]Pobieranie pakietu instalacyjnego[/COLOR]', '',
              '[COLOR lime]Chwilę to potrwa...[/COLOR]')

    if build_type == 'free':
        url = '/download.php?type=free&version={v}'.format(
            v=KODI_VERSION,
        )
    elif build_type == 'paid':
        url = '/download.php?type=paid&version={v}&password={p}'.format(
            v=KODI_VERSION,
            p=password,
        )
    else:
        # Unknown type
        return None

    downloader.download(url=_SERVER_ + url, dest=zip_path, dp=progress)
    addonfolder = xbmc.translatePath(os.path.join('special://', 'home'))

    # Wait a bit.
    time.sleep(2)

    progress.update(0, '[B][COLOR yellow]Krok 2 -[/COLOR][/B] [COLOR violet]Wypakowywanie pobranego pakietu[/COLOR]')
    print '======================================='
    print addonfolder
    print '======================================='
    extract.extract_all(zip_path, addonfolder, progress)

    killxbmc()


def killxbmc():
    choice = xbmcgui.Dialog().yesno('[COLOR lime]ZAKOŃCZONO :)[/COLOR]', 'Jedynym sposobem by Kodi przyjął nakladkę jest [COLOR red]wymuszenie zamknięcia.[/COLOR]', nolabel='Anuluj',yeslabel='Wymuś')
    if choice == 0:
        return
    elif choice == 1:
        pass
    myplatform = current_platform()
    print "Platform: " + str(myplatform)
    if myplatform == 'osx': # OSX
        print "############   try osx force close  #################"
        try: os.system('killall -9 XBMC')
        except: pass
        try: os.system('killall -9 Kodi')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA  !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie [COLOR=lime]NIE[/COLOR] zamykaj kodi poprzez przycisk w menu!",'')
    elif myplatform == 'linux': #Linux
        print "############   try linux force close  #################"
        try: os.system('killall XBMC')
        except: pass
        try: os.system('killall Kodi')
        except: pass
        try: os.system('killall -9 xbmc.bin')
        except: pass
        try: os.system('killall -9 kodi.bin')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA  !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie [COLOR=lime]NIE[/COLOR] zamykaj kodi poprzez przycisk w menu!",'')
    elif myplatform == 'android': # Android
        print "############   try android force close  #################"
        try: os.system('adb shell am force-stop org.xbmc.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.kodi')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc.xbmc')
        except: pass
        try: os.system('adb shell am force-stop org.xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA !!![/COLOR][/B]", "Twój system został wykryty jako [COLOR green]Android[/COLOR], ", "[COLOR=yellow][B]NALEŻY[/COLOR][/B] wymusić zamknięcie Kodi. [COLOR=green]OPCJA 1:[/COLOR] Przejdź do kart ostatich aplikacji i zamknij Kodi (przeciągnij z listy). [COLOR=green]OPCJA 2:[/COLOR] Przejdź do managera zadań by wymusić zamknięcie Kodi. [COLOR=green]OPCJA 3:[/COLOR] Zwyczajnie zrestartuj urządzenie",'')
    elif myplatform == 'windows': # Windows
        print "############   try windows force close  #################"
        try:
            os.system('@ECHO off')
            os.system('tskill XBMC.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('tskill Kodi.exe')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im Kodi.exe /f')
        except: pass
        try:
            os.system('@ECHO off')
            os.system('TASKKILL /im XBMC.exe /f')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie. [COLOR=lime]NIE[/COLOR] zamykaj Kodi poprzez przycisk w menu!","Wciśnij lewy Ctrl+Shift+ESC, pokaż więcej szczegółów, w procesach odnajdź KODI i zakończ to zadanie i uruchom Kodi ponownie")
    else: #ATV
        print "############   try atv force close  #################"
        try: os.system('killall AppleTV')
        except: pass
        print "############   try raspbmc force close  #################" #OSMC / Raspbmc
        try: os.system('sudo initctl stop kodi')
        except: pass
        try: os.system('sudo initctl stop xbmc')
        except: pass
        dialog.ok("[COLOR=red][B]UWAGA !!![/COLOR][/B]", "Jeśli widzisz tę informację oznacza to, że wymuszenie zamknięcia", "nie mogło być wykonane. Wymuś zamknięcie Kodi ręcznie. [COLOR=lime]NIE[/COLOR] zamykaj Kodi poprzez przycisk w menu!","Twoja platforma nie mogła być wykryta, po prostu odłącz zasilanie i uruchom Kodi ponownie")



def current_platform():
    cmds = ('system.platform.android', 'system.platform.linux', 'system.platform.windows',
            'system.platform.osx', 'system.platform.atv2', 'system.platform.ios')

    for cmd in cmds:
        if xbmc.getCondVisibility(cmd):
            return cmd.split('.')[-1]

    raise RuntimeError('Unknown platform')


def add_directory(name, url, mode, iconimage, fanart, description):
    u = '{bin}?url={url}&mode={mode}&name={name}&iconimage={icon}&fanart={fanart}&description={desc}'.format(
        bin=sys.argv[0],
        url=quote_plus(url),
        mode=quote_plus(mode),
        name=quote_plus(name),
        icon=quote_plus(iconimage),
        fanart=quote_plus(fanart),
        desc=quote_plus(description),
    )

    liz = xbmcgui.ListItem(name, iconImage='DefaultFolder.png', thumbnailImage=iconimage)
    liz.setInfo(type='Video', infoLabels={'Title': name, 'Plot': description})
    liz.setProperty('Fanart_Image', fanart)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz, isFolder=False)
    return ok


def get_params():
    query_string = sys.argv[2].replace('?', '')
    params = defaultdict(lambda: '')
    for k, v in parse_qsl(query_string, keep_blank_values=True):
        params[k] = v

    return params


def set_view(content, view_type):
    # set content type so library shows more views and info
    if content:
        xbmcplugin.setContent(int(sys.argv[1]), content)
    if addon.getSetting('auto-view') == 'true':
        xbmc.executebuiltin('Container.SetViewMode(%s)' % addon.getSetting(view_type))


def get_password():
    password = addon.getSetting(id='paid')
    if password:
        return password

    keyboard = xbmc.Keyboard('', 'Wprowadź klucz instalacyjny', False)
    keyboard.doModal()

    if not keyboard.isConfirmed():
        return None

    text = keyboard.getText()
    if not text:
        return None

    url = '/download.php?type=paid&version={v}&password={t}'.format(
        v=KODI_VERSION,
        t=text,
    )

    content_type = get_type(url=_SERVER_ + url)
    if content_type == 'application/json':
        content = get_content(url=_SERVER_ + url)
        data = json.loads(content)
        dialog.ok('Wystąpił błąd', data.get('message', '<UNKNOWN>'))
        return None
    else:
        addon.setSetting(id='paid', value=text)
        return text


def process_parameters(p):
    if p['url'] == 'free':
        return download_build(build_type='free')

    if p['url'] == 'paid':
        password = get_password()
        if not password:
            return None

        return download_build(build_type='paid', password=password)


def plugin_main():
    params = get_params()

    print str(PATH) + ': ' + str(ADDON_VERSION)
    print 'Mode: ' + params['mode']
    print 'URL: ' + params['url']
    print 'Name: ' + params['name']
    print 'IconImage: ' + params['iconimage']

    if not params['mode'] or not params['url'] or len(params['url']) < 1:
        show_categories()
    else:
        process_parameters(params)

    xbmcplugin.endOfDirectory(int(sys.argv[1]))


plugin_main()
